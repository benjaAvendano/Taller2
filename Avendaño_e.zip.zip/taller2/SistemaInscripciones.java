/**
 * 
 */
package taller2;

/**
 * @author Usuario
 *
 */
public interface SistemaInscripciones {
	
	public boolean ingresarEstudiantes();
	public boolean ingresarAsignaturas();
	public void eliminarAsignatura();
	