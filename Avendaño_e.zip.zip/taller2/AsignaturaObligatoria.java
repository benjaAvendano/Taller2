/**
 * @
 */
package taller2;

/**
 * @author Usuario
 *
 */
public class AsignaturaObligatoria extends Asignatura {
	/**
	 * @param codigo de la Asignatura
	 * @param nombre de la Asignatura
	 * @param creditos de la Asignatura
	 * @param tipo de la Asignatura
	 * @param nivel en la Malla
	 * @param cantidad de Asignaturas Pre requisito
	 * @param codigos de las Asignaturas
	 */
	public AsignaturaObligatoria(int codigoAsig, String nombreAsig, int creditosAsig, String tipoAsig, int nivelMalla,
			int cantAsigPRequisito, int codigoAsig2) {
		super(codigoAsig, nombreAsig, creditosAsig, tipoAsig);
		this.nivelMalla = nivelMalla;
		this.cantAsigPRequisito = cantAsigPRequisito;
		
	}
	private int nivelMalla;
	private int cantAsigPRequisito;
	private int codigoAsig;
	/**
	 * @return the nivelMalla
	 */
	public int getNivelMalla() {
		return nivelMalla;
	}
	/**
	 * @param nivelMalla the nivelMalla to set
	 */
	public void setNivelMalla(int nivelMalla) {
		this.nivelMalla = nivelMalla;
	}
	/**
	 * @return the cantAsigPRequisito
	 */
	public int getCantAsigPRequisito() {
		return cantAsigPRequisito;
	}
	/**
	 * @param cantAsigPRequisito the cantAsigPRequisito to set
	 */
	public void setCantAsigPRequisito(int cantAsigPRequisito) {
		this.cantAsigPRequisito = cantAsigPRequisito;
	}
	/**
	 * @return the codigoAsig
	 */
	public int getCodigoAsig() {
		return codigoAsig;
	}
	/**
	 * @param codigoAsig the codigoAsig to set
	 */
	public void setCodigoAsig(int codigoAsig) {
		this.codigoAsig = codigoAsig;
	}
	
	
	
	
	

	
	
}