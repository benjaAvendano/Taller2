/**
 * 
 */
package taller2;

import java.io.IOException;
import ucn.ArchivoEntrada;
import ucn.Registro;
import ucn.StdIn;
import ucn.StdOut;


/**
 * @author Usuario
 *
 */
public class App {
	public static void leerEstudiantes(SistemaInscripciones sistema) throws IOException {
		ArchivoEntrada archivo = new ArchivoEntrada("estudiantes.txt");
		boolean ingreso = true;
		while(!archivo.isEndFile() && ingreso) {
			Registro registro = archivo.getRegistro();
			int rutEst = registro.getInt();
			String correoEst = registro.getString();
			int nivelEst = registro.getInt();
			String claveEst = registro.getString();
			int asigCursadas = registro.getInt();
			int codigoAsig = registro.getInt();
			ingreso = sistema.ingresarEstudiante();
		}
		archivo.close();
		
	}

	public static void leerAsignaturas(SistemaInscripciones sistema) throws IOException {
		ArchivoEntrada archivo = new ArchivoEntrada("asignaturas.txt");
		boolean ingreso = true;
		while(!archivo.isEndFile() && ingreso) {
			Registro registro = archivo.getRegistro();
			int codigoAsig = registro.getInt();
			int creditosAsig = registro.getInt();
			String tipoAsig = registro.getString();
			int nivelMalla = registro.getInt();
			int cantAsigPRequisito = registro.getInt();
			
			if (tipoAsig = "obligatoria") {
				ingreso = sistema.ingresarAsignaturaObligatoria(codigoAsig,creditosAsig,tipoAsig,nivelMalla;
				cantAsigPRequisito,codigoAsig);
			}
			
			else {
				ingreso = sistema.ingresarAsignaturaOpcional(codigoAsig,creditosAsig,tipoAsig);
			}
				
			
			
		}
		arch.close();
		
	}
	

	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) throws IOException {
		
		SistemaInscripciones sistema = new SistemaInscripcionesImpl();
		
		leerEstudiantes(sistema);
		leerAsignaturas(sistema);
		leerProfesores(sistema);
		leerParalelos(sistema);
	}








}


	
	
