/**
 * 
 */
package taller2;

/**
 * @author Usuario
 *
 */
public class Profesores {
	private int rutProfe;
	private String correo;
	private String claveProfe;
	private int salario;
	
	
	/**
	 * @param rutProfe
	 * @param correo
	 * @param claveProfe
	 * @param salario
	 */
	public Profesores(int rutProfe, String correo, String claveProfe, int salario) {
		super();
		this.rutProfe = rutProfe;
		this.correo = correo;
		this.claveProfe = claveProfe;
		this.salario = salario;
	}
	









}




