package taller2;


/**
 * @author Benjamin Avenda�o
 *
 */
public class Asignatura {
	
	private int codigoAsig;
	private String nombreAsig;
	private int creditosAsig;
	private String tipoAsig;
	
	/**
	 * @param codigo de la Asignatura
	 * @param nombre de la Asignatura
	 * @param creditos de la Asignatura
	 * @param tipo de la Asignatura
	 */
	public Asignatura(int codigoAsig, String nombreAsig, int creditosAsig, String tipoAsig) {
		super();
		this.codigoAsig = codigoAsig;
		this.nombreAsig = nombreAsig;
		this.creditosAsig = creditosAsig;
		this.tipoAsig = tipoAsig;
	}

	/**
	 * @return the codigoAsig
	 */
	public int getCodigoAsig() {
		return codigoAsig;
	}

	/**
	 * @param codigoAsig the codigoAsig to set
	 */
	public void setCodigoAsig(int codigoAsig) {
		this.codigoAsig = codigoAsig;
	}

	/**
	 * @return the nombreAsig
	 */
	public String getNombreAsig() {
		return nombreAsig;
	}

	/**
	 * @param nombreAsig the nombreAsig to set
	 */
	public void setNombreAsig(String nombreAsig) {
		this.nombreAsig = nombreAsig;
	}

	/**
	 * @return the creditosAsig
	 */
	public int getCreditosAsig() {
		return creditosAsig;
	}

	/**
	 * @param creditosAsig the creditosAsig to set
	 */
	public void setCreditosAsig(int creditosAsig) {
		this.creditosAsig = creditosAsig;
	}

	/**
	 * @return the tipoAsig
	 */
	public String getTipoAsig() {
		return tipoAsig;
	}

	/**
	 * @param tipoAsig the tipoAsig to set
	 */
	public void setTipoAsig(String tipoAsig) {
		this.tipoAsig = tipoAsig;
	}


	

	
	



}
