/**
 * 
 */
package taller2;

/**
 * @author Usuario
 *
 */
public class AsignaturaOpcional extends Asignatura{

	public AsignaturaOpcional(int codigoAsig, String nombreAsig, int creditosAsig, String tipoAsig) {
		super(codigoAsig, nombreAsig, creditosAsig, tipoAsig);
		
	}
	
}
