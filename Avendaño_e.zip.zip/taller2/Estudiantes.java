/**
 * 
 */
package taller2;

/**
 * @author Usuario
 *
 */
public class Estudiantes {
	private int rutEst;
	private String correoEst;
	private int nivelEst;
	private String claveEst;
	private int asigCursadas;
	private int codigoAsig;
	private ListaAsignaturas listaAsignaturas;
	
	
	/**
	 * @return the rutEst
	 */
	public int getRutEst() {
		return rutEst;
	}
	/**
	 * @param rutEst the rutEst to set
	 */
	public void setRutEst(int rutEst) {
		this.rutEst = rutEst;
	}
	/**
	 * @return the correoEst
	 */
	public String getCorreoEst() {
		return correoEst;
	}
	/**
	 * @param correoEst the correoEst to set
	 */
	public void setCorreoEst(String correoEst) {
		this.correoEst = correoEst;
	}
	/**
	 * @return the nivelEst
	 */
	public int getNivelEst() {
		return nivelEst;
	}
	/**
	 * @param nivelEst the nivelEst to set
	 */
	public void setNivelEst(int nivelEst) {
		this.nivelEst = nivelEst;
	}
	/**
	 * @return the claveEst
	 */
	public String getClaveEst() {
		return claveEst;
	}
	/**
	 * @param claveEst the claveEst to set
	 */
	public void setClaveEst(String claveEst) {
		this.claveEst = claveEst;
	}
	/**
	 * @return the asigCursadas
	 */
	public int getAsigCursadas() {
		return asigCursadas;
	}
	/**
	 * @param asigCursadas the asigCursadas to set
	 */
	public void setAsigCursadas(int asigCursadas) {
		this.asigCursadas = asigCursadas;
	}
	/**
	 * @return the codigoAsig
	 */
	public int getCodigoAsig() {
		return codigoAsig;
	}
	/**
	 * @param codigoAsig the codigoAsig to set
	 */
	public void setCodigoAsig(int codigoAsig) {
		this.codigoAsig = codigoAsig;
	}
	/**
	 * @return the notaFinal
	 */
	public int getNotaFinal() {
		return notaFinal;
	}
	/**
	 * @param notaFinal the notaFinal to set
	 */
	public void setNotaFinal(int notaFinal) {
		this.notaFinal = notaFinal;
	}
	private int notaFinal;
	/**
	 * @param rutEst
	 * @param correoEst
	 * @param nivelEst
	 * @param claveEst
	 * @param asigCursadas
	 * @param codigoAsig
	 * @param notaFinal
	 */
	public Estudiantes(int rutEst, String correoEst, int nivelEst, String claveEst, int asigCursadas, int codigoAsig,
			int notaFinal) {
		super();
		this.rutEst = rutEst;
		this.correoEst = correoEst;
		this.nivelEst = nivelEst;
		this.claveEst = claveEst;
		this.asigCursadas = asigCursadas;
		this.codigoAsig = codigoAsig;
		this.notaFinal = notaFinal;
	}
}
	

	
