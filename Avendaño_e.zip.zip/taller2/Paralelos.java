/**
 * 
 */
package taller2;

/**
 * @author Usuario
 *
 */
public class Paralelo {
	private int numeroParalelo;
	private int codigoParalelo;
	private int rutProfe;
	
	
}
